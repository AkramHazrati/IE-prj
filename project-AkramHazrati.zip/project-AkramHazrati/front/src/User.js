import { useSelector, useDispatch } from 'react-redux';
import Navbar from './Navbar';
import { useCookies } from 'react-cookie';
import { change_id } from './userSlice';
import { useNavigate } from "react-router-dom";
import './User.css';

function User() {

  let dispatch = useDispatch();
  let navigate = useNavigate();
  let current_user_id = useSelector((state) => state.user.user_id);
  let current_user_type = useSelector((state) => state.user.user_type);
  let current_user_name = useSelector((state) => state.user.user_name);
  const [cookies, removeCookie] = useCookies(['user_id', 'user_type']);


  function logout(){
    removeCookie('user_type');
    removeCookie('user_id');
    
    dispatch(change_id(-1));
    navigate("/");
  }

  return (
    <div className="usr">
      <Navbar />
      <div className="user_c">
        <p>صفجه کاربر</p>
        <button onClick={logout} className='btn-logout'>خروج</button>
      </div>
    </div>
  );
}

export default User;
