import Navbar from './Navbar';
import { useState } from 'react';
import { useNavigate } from "react-router-dom";
import './Products.css';

function Products(Props) {

    let navigate = useNavigate();
    let [input, setInput] = useState('');


    return (
        <div className="container">
            <Navbar />
            <div className="products-c">
                <img src='' />
                <p>اطلاعات محصول</p>
                <p>قیمت</p>
            </div>
        </div>
    );
}

export default Products;
