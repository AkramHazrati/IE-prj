import './Navbar.css';
import { useSelector } from 'react-redux';
import { Link } from "react-router-dom";

function Navbar() {

  let user_id = useSelector((state) => state.user.user_id);
  let user_name = useSelector((state) => state.user.user_name);


  function user_section() {
    if (user_id == -1) {
      return (<Link to="/login">ورود</Link>);
    }
    else{
      return (<Link to="/user">welcome, {user_name}</Link>);
    }
  }

  return (
    <div className="navbar">
      <button className='btn-login'>{user_section()}</button>
      <li>لپ تاپ</li>
      <li>گوشی همراه</li>
      
    </div>
  );
}

export default Navbar;
